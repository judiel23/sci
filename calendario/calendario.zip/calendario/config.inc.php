<?php
$dbhost="localhost";
$dbname="movilnet";
$dbuser="root";
$dbpass="";

$uploaddir="/tmp/";
$con=mysqli_connect($dbhost,$dbuser,$dbpass);
?>
